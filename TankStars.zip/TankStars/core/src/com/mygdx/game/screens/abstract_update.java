package com.mygdx.game.screens;

public abstract class abstract_update {
    public abstract void update(float delta);
    public abstract void initButtons();
}
