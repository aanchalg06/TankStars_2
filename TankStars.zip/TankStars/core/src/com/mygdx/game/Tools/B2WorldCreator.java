package com.mygdx.game.Tools;

import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.physics.box2d.World;

public class B2WorldCreator {
    int PPM =100;
    private B2WorldCreator(int next){
        this.PPM=next;
    }

}