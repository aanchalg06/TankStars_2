<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Land" tilewidth="20" tileheight="20" tilecount="1980" columns="60">
 <image source="Land.png" width="1200" height="675"/>
</tileset>
