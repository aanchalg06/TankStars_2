<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Surface" tilewidth="18" tileheight="20" spacing="16" margin="16" tilecount="1680" columns="56">
 <image source="Surface.png" width="1920" height="1080"/>
</tileset>
